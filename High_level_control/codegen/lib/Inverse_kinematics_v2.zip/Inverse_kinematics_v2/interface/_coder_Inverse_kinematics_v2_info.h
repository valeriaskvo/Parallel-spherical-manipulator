/*
 * File: _coder_Inverse_kinematics_v2_info.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 03-Apr-2020 11:57:13
 */

#ifndef _CODER_INVERSE_KINEMATICS_V2_INFO_H
#define _CODER_INVERSE_KINEMATICS_V2_INFO_H

/* Include Files */
#include "mex.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif

/*
 * File trailer for _coder_Inverse_kinematics_v2_info.h
 *
 * [EOF]
 */
