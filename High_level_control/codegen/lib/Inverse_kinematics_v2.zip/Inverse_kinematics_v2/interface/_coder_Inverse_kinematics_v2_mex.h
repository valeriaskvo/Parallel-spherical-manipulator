/*
 * File: _coder_Inverse_kinematics_v2_mex.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 03-Apr-2020 11:57:13
 */

#ifndef _CODER_INVERSE_KINEMATICS_V2_MEX_H
#define _CODER_INVERSE_KINEMATICS_V2_MEX_H

/* Include Files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "_coder_Inverse_kinematics_v2_api.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs,
  const mxArray *prhs[]);
extern emlrtCTX mexFunctionCreateRootTLS(void);

#endif

/*
 * File trailer for _coder_Inverse_kinematics_v2_mex.h
 *
 * [EOF]
 */
