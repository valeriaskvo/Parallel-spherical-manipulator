/*
 * File: Inverse_kinematics_v2_initialize.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 03-Apr-2020 11:57:13
 */

#ifndef INVERSE_KINEMATICS_V2_INITIALIZE_H
#define INVERSE_KINEMATICS_V2_INITIALIZE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Inverse_kinematics_v2_types.h"

/* Function Declarations */
extern void Inverse_kinematics_v2_initialize(void);

#endif

/*
 * File trailer for Inverse_kinematics_v2_initialize.h
 *
 * [EOF]
 */
