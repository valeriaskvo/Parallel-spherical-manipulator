/*
 * File: Inverse_kinematics_v2_types.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 03-Apr-2020 11:57:13
 */

#ifndef INVERSE_KINEMATICS_V2_TYPES_H
#define INVERSE_KINEMATICS_V2_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for Inverse_kinematics_v2_types.h
 *
 * [EOF]
 */
